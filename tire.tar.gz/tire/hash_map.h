#ifndef __HASH_MAP__
#define __HASH_MAP__

#include <pthread.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string>


#include "uthash.h"



#include <set>
#include <map>
#include <vector>
#include <boost/pool/singleton_pool.hpp>

using namespace boost;

#define  UTHASH__KEY_LEN 1000

//    pthread_mutex_t utmutex;

//template <struct  T, int i>    // template<模板参数表>
template<class T>
class HashMap
{
    struct info_tag{};
    typedef boost::singleton_pool<info_tag, sizeof(T)> uthash_pool;

    public:
    HashMap(void)
    {
	utmutex=PTHREAD_MUTEX_INITIALIZER;
	uthash_key_length = UTHASH__KEY_LEN;
	printf("%s\n", __func__);
    }

    ~HashMap( void ){
	del_all();
	printf("%s\n", __func__);
    };

    int count()
    {
	return HASH_COUNT(uthash_handle);
    }


    virtual int add(T &item) {

	T *s= (T *)uthash_pool::malloc();
	memcpy(s, &item, sizeof(T));
	//printf("\nadd hash_key (%s)\n", s->hash_key);
#if 0
	char buf_hash_key[1000];
	int ret = open("/data/rtb/hash_key", O_RDWR| O_CREAT|O_APPEND ,0777 );
	::write(ret,s->hash_key, strlen(s->hash_key));
	::write(ret,"\n", 1);
	close(ret);
#endif
	pthread_mutex_lock(&utmutex);
	HASH_ADD_STR( uthash_handle, hash_key, s );  // id: name of hash_key field
	pthread_mutex_unlock(&utmutex);
	return 0;
    }

    virtual T *find(T &item) {
	T *s; 
	item.hash_key[uthash_key_length-1] = 0;
	if(uthash_key_length < strlen(item.hash_key) -1){return NULL;}
	HASH_FIND_STR( uthash_handle, item.hash_key , s); 
	return s;
    }


    virtual void del(T *item) {
	pthread_mutex_lock(&utmutex);
	HASH_DEL( uthash_handle, item);  // media_price: pointer to deletee
	pthread_mutex_unlock(&utmutex);
	uthash_pool::free (item);
    }    

#if 1
    void save(std::string file_name) {
	T *current, *tmp;
	int cnt = 0;
	char buf[1024];
	int write_len = 0;
	char cmd[1024];
	snprintf(cmd, sizeof(cmd), "> %s", file_name.c_str());
	::system(cmd);

	T info;
	int ret = open(file_name.c_str(), O_RDWR| O_CREAT|O_APPEND ,0777 );
	HASH_ITER(hh, uthash_handle, current, tmp) {

	    pthread_mutex_lock(&utmutex);
	    memcpy(&info, current, sizeof(T));
	    pthread_mutex_unlock(&utmutex);
	    write_len = snprintf(buf, sizeof(buf), "%s",
		    info.hash_key);
	    ::write(ret, buf, write_len);
	    cnt++;
	}

	close(ret);
    }
#endif
    void print() {
	T *current, *tmp;
	int cnt = 0;
	char buf[1024];
	int write_len = 0;

	T info;
	printf("top\tcount\tcmd\n");
	HASH_ITER(hh, uthash_handle, current, tmp) {

	    pthread_mutex_lock(&utmutex);
	    memcpy(&info, current, sizeof(T));
	    pthread_mutex_unlock(&utmutex);
	    write_len = snprintf(buf, sizeof(buf), "%d\t%d\t%s",

		    cnt + 1, info.count, info.hash_key);
	    //if( info.hash_key[strlen(info.hash_key) -1]  == '\n' )
	    {
		printf("%s", buf);
		cnt++;
	    }
	    if (cnt > 100){
		//break;
	    }
	}

    }

    void del_all() {
	T *current, *tmp;
	HASH_ITER(hh, uthash_handle, current, tmp) {

	    pthread_mutex_lock(&utmutex);
	    HASH_DEL( uthash_handle, current);
	    uthash_pool::free (current);
	    pthread_mutex_unlock(&utmutex);
	}

    }
/*
    void sort() {
	pthread_mutex_lock(&utmutex);
	HASH_SORT(uthash_handle, sort_by_ctr);
	pthread_mutex_unlock(&utmutex);
    }   

    int sort_by_ctr(T *a, T *b){
	return b->count - a->count;
    }   
    */
    int test();

    public:
    T *uthash_handle;
    pthread_mutex_t utmutex;
    int uthash_key_length;
    pthread_mutex_t utmutex2;
    //int a;

};





#endif /* __HASH_MAP */
