#ifndef __TIRE__
#define __TIRE__

#include <stdio.h>
#include <iostream>
#include <map>
#include <string.h>
#include <string>
#include <stdlib.h>

using namespace std;


#include "uttire.h"


struct tire_tree_t{
    std::map<std::string, struct tire_tree_t> tire_tree;
    int count;
    int height;
};


class TireTree
{
    public:
	typedef std::map<std::string, struct tire_tree_t>::iterator tire_iter_t;
	TireTree(char *name);
	int read_word_from_logfile(char *file);


	void traval_breadth(tire_iter_t it_root);
	void traval_deep_pre(tire_iter_t it_root, UtTire<tire_search_tree_t> &uttire, tire_search_tree_t info);

	void search_key(char *key, int length);

	void search_key();
	void add_keyword(char *key, int length);

	void  find_word_in_tree(tire_iter_t it_root, int height,UtTire<tire_search_tree_t> &uttire, tire_search_tree_t info);

	tire_iter_t _root;
	std::string _tire_name;
	char _split_length;
	std::map<std::string, struct tire_tree_t> _hot_update_map;
	int total_count;
	//Tire<UtHash<tire_search_tree_t>> uttire;
};
#endif
