#include "hash_map.h"
#include "uttire.h"


UtTire<tire_search_tree_t> test;
//UtTire<tire_search_tree_t> test;

template<class T>
void UtTire<T>::sort()
{
    pthread_mutex_lock(&this->utmutex);
    HASH_SORT(this->uthash_handle, sort_by_ctr);
    pthread_mutex_unlock(&this->utmutex);
}   


int test_tire(){
    tire_search_tree_t info;
    strncpy(info.hash_key, "123",sizeof(info.hash_key) -1);
    info.length = 1;
    test.add(info);
    tire_search_tree_t *s = test.find(info);
    if(NULL != s){
	printf("%s %d\n", s->hash_key, s->length);
    }
    strncpy(info.hash_key, "234",sizeof(info.hash_key) -1);
    info.length++;
    test.add(info);
    s = test.find(info);
    if(NULL != s){
	printf("%s %d\n", s->hash_key, s->length);
    }

    printf("count %d\n", test.count());
    test.del(s);

    printf("count %d\n", test.count());
}

void get_url_count(char *file){

    FILE * fp;
    char * line = NULL;
    size_t len = 0;
    ssize_t read;

    fp = fopen(file, "r");
    if (fp == NULL)
	exit(EXIT_FAILURE);

    tire_search_tree_t info;

    while ((read = getline(&line, &len, fp)) != -1) {
#if 0
	printf("Retrieved line of length %zu :\n", read);
	printf("%s", line);
#endif
	memset(&info, 0 , sizeof(info));
	strncpy(info.hash_key, line,sizeof(info.hash_key) -1);
	tire_search_tree_t *s = test.find(info);
	if(NULL != s){
	    s->count++;
	}
	else{
	    info.count =1;
	    test.add(info);
	}

    }
    if (line)
	free(line);
    test.sort();
    test.print();
}
