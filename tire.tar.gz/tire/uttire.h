#ifndef __UTTIRE__
#define __UTTIRE__


#include "hash_map.h"

using namespace std;


class tire_search_tree_t {
    public:
    int  length;
    char update_counter;
    char *data;
    int count;
    char hash_key[UTHASH__KEY_LEN];
    UT_hash_handle hh;         // makes this structure hashable 
};

/*
typedef struct tire_search_tree_t {
    int  length;
    char update_counter;
    char *data;
    char key[UTHASH__KEY_LEN];
    UT_hash_handle hh;         // makes this structure hashable 
}user_info;
*/

#if 1
template<class T>
class UtTire:public HashMap<T>
{
    public:
    public:
	UtTire(){
		printf("%s sizeof(*this) %d \n",__func__, sizeof(*this));
	}
	~UtTire(){
	    printf("%s\n",__func__);
	}
	int sort_by_ctr(T *a, T *b){
	    return b->count - a->count;
	}
	void sort();
	//int aaa[100];

};
#endif


int test_tire();

#endif
