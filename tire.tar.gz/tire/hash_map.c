
#include <pthread.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string>


#include "uthash.h"
#include "hash_map.h"



#include <set>
#include <map>
#include <vector>

//template<typename T>
//int HashMap<T>::test(){}

#if 0
#include <map>
#include <vector>
#include <boost/pool/singleton_pool.hpp>

using namespace boost;

#endif
