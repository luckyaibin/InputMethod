#include <stdio.h>
#include <iostream>
#include <map>
#include <deque>
#include <string.h>
#include <string>
#include <stdlib.h>


#include "tire.h"
#include "uttire.h"


using namespace std;





TireTree::TireTree(char *name){
    struct tire_tree_t tree;
    _tire_name = name;
    total_count = 0;
    tree.count = 1;
    _split_length = 1;
    tree.height = -1;

    _hot_update_map.insert(std::pair<string, struct tire_tree_t>(_tire_name, tree));
    _root = _hot_update_map.find(_tire_name);
    if(_root == _hot_update_map.end()){
	printf("tire _root is empty\n");
    }
}


void TireTree::add_keyword(char *key, int length){

    	
	std::string keyword;
	std::map<std::string, struct tire_tree_t>::iterator it_root = _root;
	for( int i = 0; i * _split_length  < length ; i++)
	{
	    keyword.replace(0,_split_length, key +  _split_length * i , _split_length);

	    std::map<std::string, struct tire_tree_t>::iterator it = it_root->second.tire_tree.find(keyword);
	    if(it != it_root->second.tire_tree.end()){
		if(i+1 == length)
		{
		    it->second.count++;
		}
		//printf("i %d length %d\n", i, length);
		//printf("(%s)", keyword.c_str());
	    }
	    else{
		//printf("%s", keyword.c_str());
		struct tire_tree_t tree;
		if(i+1 == length){
		    tree.count = 1;
		}
		else{

		    tree.count = 0;
		}
		tree.height = i;
		it_root->second.tire_tree.insert(std::pair<string, struct tire_tree_t>(keyword, tree));
	    }
	    it_root = it_root->second.tire_tree.find(keyword);

	}

}


int TireTree::read_word_from_logfile(char *file){
    FILE * fp;
    char * line = NULL;
    size_t len = 0;
    ssize_t read;

    fp = fopen(file, "r");
    if (fp == NULL)
	exit(EXIT_FAILURE);


    while ((read = getline(&line, &len, fp)) != -1) {
#if 0
	printf("Retrieved line of length %zu :\n", read);
	printf("%s", line);
#endif
	int length = read;
	add_keyword(line, length);
	total_count++;
	if(total_count % 1000 == 0){
		printf(" read count %d\n", total_count);		
	}

    }
    if (line)
	free(line);
}


void TireTree::traval_deep_pre(tire_iter_t it_root, UtTire<tire_search_tree_t> &uttire, tire_search_tree_t info)
{
    std::deque<tire_iter_t> stack;
    stack.push_front(it_root);
    tire_iter_t it;


    while(!stack.empty())  
    {  

	it = stack.front();
	stack.pop_front();  
	//printf("%d%s,",it->second.height, it->first.c_str());
	snprintf(info.hash_key + it->second.height * _split_length, sizeof(info.hash_key), "%s", it->first.c_str());
	if(it->second.count){
	    tire_search_tree_t *s = uttire.find(info);
	    if(NULL != s){

		printf("repeat count %d key height %d (%s)\n,",it->second.count, it->second.height,info.hash_key);
	    }
	    else{
		info.count = it->second.count;
		uttire.add(info);
		//printf("\nadd  count %d   key (%s)  height %d \n", info.count, info.hash_key, it->second.height);
	    }
	}

	tire_iter_t iter;

	for(iter=it->second.tire_tree.begin();iter!= it->second.tire_tree.end();++iter)
	{
	    stack.push_front(iter);
	}
    }


}

void TireTree::traval_breadth(tire_iter_t it_root){

    std::deque<tire_iter_t> stack;
    stack.push_back(it_root);
    tire_iter_t it;

    int c_n = -1;
    while(!stack.empty())
    {
	it = stack.front();
	stack.pop_front();

	if(c_n != it->second.height){
	    printf("\n");
	    c_n = it->second.height;
	}

	printf("%d%s,",it->second.height, it->first.c_str());


	tire_iter_t iter;
	for(iter=it->second.tire_tree.begin();iter!= it->second.tire_tree.end();++iter)
	{
	    stack.push_back(iter);
	}
    }


    return;
}



//UtTire<tire_search_tree_t> uttire;
void TireTree::search_key(char *key, int length){
 UtTire<tire_search_tree_t> uttire;
    tire_search_tree_t info;
    info.count = 100;
    strncpy(info.hash_key, key, sizeof(info.hash_key) -1);

    string keyword;
    tire_iter_t it_root = _root;

    std::map<std::string, struct tire_tree_t>::iterator it;
    int key_appear_count = 0;
    for( int i = 0; i * _split_length  < length; i++)
    {
	keyword.replace(0,_split_length, key +  _split_length * i , _split_length);

	it = it_root->second.tire_tree.find(keyword);
	if(it != it_root->second.tire_tree.end()){
	    //printf("(%s)", keyword.c_str());
	    if(i == length -1 ){
		info.length = length ;
		if(it->second.count != 0){
		    info.count = it->second.count;
		    uttire.add(info);
		}
	    }
	}
	else{
	    printf("break in  height %d  %s", i + _split_length ,keyword.c_str());
	    info.count = -1;
	    break;
	}
	it_root = it_root->second.tire_tree.find(keyword);

    }
    if(info.count != -1){
	traval_deep_pre(it_root, uttire, info);
    }
    uttire.sort();
    uttire.print();
    uttire.del_all();
}

void get_url_count(char *file);

int main(int argv,char **args)
{
    printf("sizeof tire_search_tree_t %d \n", sizeof(tire_search_tree_t));
    printf("sizeof HashMap<tire_search_tree_t> %d \n", sizeof(HashMap<tire_search_tree_t>));
    printf("sizeof UtTire<tire_search_tree_t> %d \n", sizeof(UtTire<tire_search_tree_t>));
    //test_tire();
    //get_url_count(args[1]);
    //exit(1);

    struct tire_tree_t tree;
    char key[100] = {'\0'};
    TireTree  tire_tree((char *)"TIRE");

    tire_tree.read_word_from_logfile(args[1]);
    tire_search_tree_t info;
    info.count = 100;
    //exit(1);
    while(1){

	printf("search key:");
	memset(key, 0, sizeof(key));
	int length = scanf("%s",&key);
	if(strstr(key, "quit") != NULL){
		break;
	}
	tire_tree.search_key(key, strlen(key));
    }
    exit(1);
    int search_count = 0;
    while(1){
	strncpy(key, "netstat", sizeof(key));
    	tire_tree.search_key(key, strlen(key));
	search_count++;
	if(search_count % 10000 == 0){
		printf("search count %d\n", search_count);
	}
    }
    return 0;

}

