#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "socket.h"
#include "hash_map.h"
#include "CalculateTime.h"

#include <boost/pool/singleton_pool.hpp>
using namespace boost;

T *uthash_handle[HEAP_NUM];
T_tag{};
typedef boost::singleton_pool<info_tag, sizeof(info)> uthash_pool;

pthread_mutex_t utmutex[HEAP_NUM];
//T *entry;

int get_count(int index)
{
    return HASH_COUNT(uthash_handle[index]);
}



int add(int index, T &host) {

    if (strlen(host.key)> (DOMAIN_URL_LEN -1) ) return -1;
    T *s= (T*)uthash_pool::malloc();
    memcpy(s, &host, sizeof(T));
#if 0
    char buf_key[1000];
    int ret = open("/data/rtb/key", O_RDWR| O_CREAT|O_APPEND ,0777 );
    ::write(ret,s->key, strlen(s->key));
    ::write(ret,"\n", 1);
    close(ret);
#endif
    pthread_mutex_lock(&utmutex[index]);
    HASH_ADD_STR( uthash_handle[index], key, s );  // id: name of key field
    pthread_mutex_unlock(&utmutex[index]);
    return 0;
}


T *find(int index,T &host) {
    T *s;
    host.key[DOMAIN_URL_LEN-1] = 0;
    if(DOMAIN_URL_LEN < strlen(host.key) -1){return NULL;}
    HASH_FIND_STR( uthash_handle[index], host.key , s);
    return s;
}

void delete(int index, T *host) {
    pthread_mutex_lock(&utmutex[index]);
    HASH_DEL( uthash_handle[index], host);  // media_price: pointer to deletee
    pthread_mutex_unlock(&utmutex[index]);
    uthash_pool::free (host);
}

void save(int index) {
    T *current, *tmp;
    cTime onlyTime;
    onlyTime.Start();
    int cnt = 0;
    char buf[1024];
    int write_len = 0;
    char cmd[1024];
    char rt_file[1024];
    snprintf(rt_file, sizeof(rt_file), "%s_%d_%d",USER_RT_INFO, g_media_server_port, g_dev_id);
    snprintf(cmd, sizeof(cmd), "> %s", rt_file);
    ::system(cmd);

    T info;	
    int ret = open(rt_file, O_RDWR| O_CREAT|O_APPEND ,0777 );
    HASH_ITER(hh, uthash_handle[index], current, tmp) {

	pthread_mutex_lock(&utmutex[index]);
	memcpy(&info, current, sizeof(T));
	pthread_mutex_unlock(&utmutex[index]);
	write_len = snprintf(buf, sizeof(buf), "%s",
		info.key)
	::write(ret, buf, write_len);
	cnt++;
    }

    close(ret);
    onlyTime.End();
    printf( "save media_price into  index %d  data count %d    %d.%06d seconds\n",
	    index, cnt, (int)onlyTime.tDiff.tv_sec, (int)onlyTime.tDiff.tv_usec);
}

void delete_expire(int index) {
    T *current, *tmp;
    //printf("delete index %d  expire data ...\n", index);
    cTime onlyTime;
    onlyTime.Start();
    int cnt = 0;
    int ret = open("delete", O_RDWR| O_CREAT|O_APPEND ,0777 );
    HASH_ITER(hh, uthash_handle[index], current, tmp) {
	//usleep(10);
	{
	    pthread_mutex_lock(&utmutex[index]);
	    HASH_DEL(uthash_handle[index],current);  // delete it (media_prices advances to next)
	    pthread_mutex_unlock(&utmutex[index]);
#if 1
	    if ( (cnt % 10000) == 0)
	    {
		::write(ret, current->key, strlen(current->key));
		::write(ret,"\n", 1);
	    }
#endif
	    uthash_pool::free(current);            // free it
	    cnt++;
	}
    }
    close(ret);
    onlyTime.End();
    printf( "delete media_price index %d expire data count %d    %d.%06d seconds\n",
	    index, cnt, (int)onlyTime.tDiff.tv_sec, (int)onlyTime.tDiff.tv_usec);
}


#if 1
void delete_all(int index) {
    T *current, *tmp;
    pthread_mutex_lock(&utmutex[index]);
    //printf("delete index %d data ...\n", index);
    HASH_ITER(hh, uthash_handle[index], current, tmp) {
	HASH_DEL(uthash_handle[index],current);  // delete it (media_prices advances to next)
	uthash_pool::free(current);            // free it
    }
    //printf("delete index %d data OK!\n", index);
    pthread_mutex_unlock(&utmutex[index]);
}
#endif

#if 0
void delete_all(int index) {
    T *current, *tmp;
    pthread_mutex_lock(&utmutex[index]);
    while(uthash_handle[index])
    {
	//printf("delete index %d data ...\n", index);
	int cnt = 0;
	current =uthash_handle[index];
	HASH_DEL(uthash_handle[index],current);  // delete it (media_prices advances to next)
	delete current->data;
	uthash_pool.free(current);            // free it
    }
    //printf("delete index %d data OK!\n", index);
    pthread_mutex_unlock(&utmutex[index]);
}
#endif
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include <unistd.h>
void print_uthash_handle(int index) {
    T *s;

    printf("=========media_price info===========\n");
    pthread_mutex_lock(&utmutex[index]);
    for(s=uthash_handle[index]; s != NULL; s=(T *)(s->hh.next)) {
	//printf("key:%s data%s\n", s->key, s->data);
#if 0
	char buf[10000];
	snprintf(buf, sizeof(buf), "%s %s\n",s->key, s->data);
	int ret = open("info", O_RDWR| O_CREAT|O_APPEND  );
	write(ret, buf, strlen(buf));
	close(ret);
#endif
    }
    printf("=====media_price count %d ========\n",get_count(index));
    pthread_mutex_unlock(&utmutex[index]);
    printf("=========media_price info===========\n");
}


int read_from_file(int hash_list)
{
    FILE * fp;
    char * line = NULL;
    size_t len = 0,length = 0; 
    ssize_t read;
    T info;
    char *cp=NULL,*cp_1 =NULL;
    int key_len = 0; 


    char rt_file[1024];
    snprintf(rt_file, sizeof(rt_file), "%s_%d_%d",USER_RT_INFO, g_media_server_port, g_dev_id);

    fp = fopen(rt_file, "r");
    if (fp == NULL)
    {    
	printf("line:%d open %s error!\n", __LINE__, rt_file);
	return -1;
    } 

    while ((read = getline(&line, &length, fp)) != -1) {
	memset(&info, 0 , sizeof(info));
	cp = line;
	STRCHR(cp_1, key_len, cp, ',');
	MEMCPY(info.key, cp, key_len);

	info.flag = atoi(cp_1+1);


	STRCHR(cp_1 ,len, cp_1+1, ',');
	info.bid_price = atof(cp_1+1);

	STRCHR(cp_1 ,len, cp_1+1, ',');
	info.bid_time = atoi(cp_1+1);
	info.improve_time = info.bid_time;

	STRCHR(cp_1 ,len, cp_1+1, ',');
	info.ok_price = atof(cp_1+1);

	STRCHR(cp_1 ,len, cp_1+1, ',');
	info.ok_time = atoi(cp_1+1);


	STRCHR(cp_1 ,len, cp_1+1, ',');
	info._ctr = atof(cp_1+1);

	STRCHR(cp_1 ,len, cp_1+1, ',');
	info._bsr = atof(cp_1+1);

	STRCHR(cp_1 ,len, cp_1+1, ',');
	info._click = atof(cp_1+1);

	STRCHR(cp_1 ,len, cp_1+1, ',');
	info._impression = atof(cp_1+1);


	STRCHR(cp_1 ,len, cp_1+1, ',');
	info._bidcount = atof(cp_1+1);

	pthread_mutex_lock(&utmutex[hash_list]);
	info.key[DOMAIN_URL_LEN-1] = '\0';
	T *s  = find(hash_list, info);
	if (NULL != s)                
	{
	    pthread_mutex_unlock(&utmutex[hash_list]);

	}
	else
	{
	    pthread_mutex_unlock(&utmutex[hash_list]);
	    add(hash_list, info);
	}
    }

    if (line)
	free(line);
    fclose(fp);
    return 0;
}

